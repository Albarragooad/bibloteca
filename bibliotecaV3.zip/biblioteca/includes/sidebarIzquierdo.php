<div class="col-sm-3"> <!--/Inicio de barra lateral izquierda-->
	<div class="left-sidebar">				
	    <div class="brands_products"><!--brands_products-->
			<h2>Categorias</h2>
			<div class="brands-name">
				<ul class="nav nav-pills nav-stacked">
				 <li><a href="#"> <span class="pull-right">(50)</span>Tecnologia</a></li>
				<li><a href="#"> <span class="pull-right">(56)</span>Web</a></li>
				<li><a href="#"> <span class="pull-right">(27)</span>Informatica</a></li>
				<li><a href="#"> <span class="pull-right">(32)</span>Programacion</a></li>
				<li><a href="#"> <span class="pull-right">(5)</span>Estadisticas</a></li>
				<li><a href="#"> <span class="pull-right">(9)</span>Finanzas</a></li>
				<li><a href="#"> <span class="pull-right">(4)</span>Administracion</a></li>
				 <li><a href="#"> <span class="pull-right">(50)</span>Tecnologia</a></li>
				<li><a href="#"> <span class="pull-right">(56)</span>Web</a></li>
				<li><a href="#"> <span class="pull-right">(27)</span>Informatica</a></li>
				<li><a href="#"> <span class="pull-right">(32)</span>Programacion</a></li>
				<li><a href="#"> <span class="pull-right">(5)</span>Estadisticas</a></li>
				<li><a href="#"> <span class="pull-right">(9)</span>Finanzas</a></li>
				<li><a href="#"> <span class="pull-right">(4)</span>Administracion</a></li>
				 <li><a href="#"> <span class="pull-right">(50)</span>Tecnologia</a></li>
				<li><a href="#"> <span class="pull-right">(56)</span>Web</a></li>
				<li><a href="#"> <span class="pull-right">(27)</span>Informatica</a></li>
				<li><a href="#"> <span class="pull-right">(32)</span>Programacion</a></li>
				<li><a href="#"> <span class="pull-right">(5)</span>Estadisticas</a></li>
				<li><a href="#"> <span class="pull-right">(9)</span>Finanzas</a></li>
				<li><a href="#"> <span class="pull-right">(4)</span>Administracion</a></li>
				</ul>
			</div>
		</div><!--/brands_products-->
		    <div class="price-range"><!--price-range-->
				<h2>Visitas</h2>
				<div class="col-md-4">
				    <img src="images/home/visitas.png" width="60" height="60">
				</div>
				<div class="col-md-8">
					<h5><b><?php  echo $numero_visitas;?> Visitas Totales</b></h5>
					<h6><b><?php  echo $visitas_hoy;?> Visitas Hoy</b></h6>
				</div>
			</div><!--/price-range-->					
	</div>
</div> <!--fin de barra lateral izquierda-->