	<div class="category-tab"><!--category-tab-->
	<h2 class="title text-center">Descargados Recientemente</h2>
						<div class="col-sm-12">
							<ul class="nav nav-tabs">
								<li class="active"><a href="#tshirt" data-toggle="tab">Java</a></li>
								<li><a href="#blazers" data-toggle="tab">PHP</a></li>
								<li><a href="#sunglass" data-toggle="tab">C#</a></li>
								<li><a href="#kids" data-toggle="tab">Javascript</a></li>
								<li><a href="#poloshirt" data-toggle="tab">HTML 5</a></li>
							</ul>
						</div>
						<div class="tab-content">
							<div class="tab-pane fade active in" id="tshirt" >
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery1.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery2.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery3.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery4.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
							</div>
							
							<div class="tab-pane fade" id="blazers" >
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery4.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery3.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery2.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery1.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
							</div>
							
							<div class="tab-pane fade" id="sunglass" >
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery3.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery4.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery1.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery2.jpg" alt="" />
												<p>Libro PDF</p>
									<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Prestar</a>
											</div>
											
										</div>
									</div>
								</div>
							</div>
							
							<div class="tab-pane fade" id="kids" >
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery1.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery2.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery3.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery4.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
							</div>
							
							<div class="tab-pane fade" id="poloshirt" >
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery2.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery4.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery3.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
								<div class="col-sm-3">
									<div class="product-image-wrapper">
										<div class="single-products">
											<div class="productinfo text-center">
												<img src="images/home/gallery1.jpg" alt="" />
												<p>Libro PDF</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-download"></i>Descargar</a>
											</div>
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div><!--/category-tab-->